import 'package:get/get.dart';
import 'package:ican/core/Loction/textApp.dart';
import 'package:ican/core/utlies/appimage.dart';

List<String> modulesSettingtitel = [
  AppText.group.tr,
  AppText.groupLeaders.tr,
  AppText.reports.tr,
];
List<String> modulesSetting = [
  AppText.settings.tr,
  AppText.group.tr,
  AppText.groupLeaders.tr,
  AppText.reports.tr,
];
List<String> modulesSettingIconName = [
  AppImageName.group,
  AppImageName.groupLeaders,
  AppImageName.order,
];
