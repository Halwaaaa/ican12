import 'package:get/get.dart';
import 'package:ican/core/Loction/textApp.dart';
import 'package:ican/core/utlies/appimage.dart';

List<String> modulesAboutTitel = [
  AppText.location.tr,
  "+963 999 136 824",
  "www..icanaleppo.co",
  'ican.aleppo@gmail.com',
];
List<String> modulesAboutIconName = [
  AppImageName.location,
  AppImageName.phone,
  AppImageName.webAdress,
  AppImageName.email,
];
