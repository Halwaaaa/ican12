enum Search {
  city,
  cuctomer,
  stauts,
}
