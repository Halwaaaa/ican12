import 'package:flutter/cupertino.dart';
import 'package:ican/core/compnated/DafultOrderInformation.dart';

class OrderInformation extends StatelessWidget {
  const OrderInformation({super.key});

  @override
  Widget build(BuildContext context) {
    return const DafultOrderInformation();
  }
}
