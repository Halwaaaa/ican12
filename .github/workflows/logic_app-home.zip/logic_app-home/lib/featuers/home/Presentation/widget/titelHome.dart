import 'package:flutter/cupertino.dart';
import 'package:get/get.dart';
import 'package:ican/core/utlies/mathed.dart';
import 'package:ican/core/Loction/textApp.dart';
import 'package:ican/core/utlies/textStyle.dart';
import 'package:google_fonts/google_fonts.dart';

class TitleHome extends StatelessWidget {
  const TitleHome({
    super.key,
  });

  @override
  Widget build(BuildContext context) {
    return Column(
      mainAxisAlignment: MainAxisAlignment.start,
      crossAxisAlignment: CrossAxisAlignment.start,
      children: [
        Mathed.heightSmal(),
        Text(AppText.homeTitle.tr,
            style: GoogleFonts.roboto(
              textStyle: ApptextStyle.textStyleApp22,
            )),
      ],
    );
  }
}
